// Mock data for conversation history
export const mockConversationHistory = [
  {
    section: 'Today',
    conversations: [
      {
        id: '1',
        title: 'Gen Z Slang Translation for "How Are..."',
        lastMessage: 'Can you help me translate this phrase into Gen Z slang?',
        timestamp: new Date(Date.now() - 1000 * 60 * 30), // 30 minutes ago
        messages: [
          {
            id: 'm1',
            text: 'Can you help me translate "How are you doing today?" into Gen Z slang?',
            sender: 'user',
            timestamp: new Date(Date.now() - 1000 * 60 * 30)
          },
          {
            id: 'm2',
            text: 'Sure! In Gen Z slang, "How are you doing today?" could be translated as:\n\n"How you been? You good?" or "What\'s the vibe today?" or simply "You good bestie?"\n\nGen Z tends to use shorter, more casual phrases with words like "vibe," "bestie," "fr" (for real), and "no cap" (no lie).',
            sender: 'assistant',
            timestamp: new Date(Date.now() - 1000 * 60 * 29)
          }
        ]
      },
      {
        id: '2',
        title: 'Futuristic Cityscape Image Request',
        lastMessage: 'I need help creating a futuristic cityscape...',
        timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2), // 2 hours ago
        messages: [
          {
            id: 'm3',
            text: 'I need help creating a futuristic cityscape with flying cars and neon lights. Can you guide me on the key elements to include?',
            sender: 'user',
            timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2)
          },
          {
            id: 'm4',
            text: 'I\'d be happy to help you design a futuristic cityscape! Here are the key elements to consider:\n\n**Architecture:**\n- Sleek, geometric skyscrapers with glass and metal\n- Vertical gardens and green spaces\n- Floating or suspended buildings\n\n**Technology:**\n- Flying cars and hovering vehicles\n- Holographic billboards and displays\n- Energy bridges connecting buildings\n\n**Lighting:**\n- Neon accent lighting in blues, purples, and cyans\n- LED strips along building edges\n- Glowing pathways and roads\n\n**Atmosphere:**\n- Misty or foggy ambiance\n- Dynamic weather systems\n- Multiple layers of air traffic',
            sender: 'assistant',
            timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2 + 1000 * 60)
          }
        ]
      }
    ]
  },
  {
    section: 'Sunday, Jun 29',
    conversations: [
      {
        id: '3',
        title: 'Integrating Google GenAI in JavaScript...',
        lastMessage: 'How do I integrate Google GenAI API in my JavaScript project?',
        timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24), // 1 day ago
        messages: [
          {
            id: 'm5',
            text: 'How do I integrate Google GenAI API in my JavaScript project? I need to make API calls from the frontend.',
            sender: 'user',
            timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24)
          },
          {
            id: 'm6',
            text: 'To integrate Google GenAI API in JavaScript, you\'ll need to:\n\n1. **Get API Key**: First, get your API key from Google AI Studio\n\n2. **Install SDK**: \n```bash\nnpm install @google/generative-ai\n```\n\n3. **Basic Implementation**:\n```javascript\nimport { GoogleGenerativeAI } from "@google/generative-ai";\n\nconst genAI = new GoogleGenerativeAI(API_KEY);\nconst model = genAI.getGenerativeModel({ model: "gemini-pro" });\n\nconst result = await model.generateContent(prompt);\nconsole.log(result.response.text());\n```\n\n**Important**: Never expose your API key in frontend code. Use environment variables or a backend proxy for production.',
            sender: 'assistant',
            timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 + 1000 * 60 * 2)
          }
        ]
      }
    ]
  },
  {
    section: 'Saturday, Jun 28',
    conversations: [
      {
        id: '4',
        title: 'React Component Optimization',
        lastMessage: 'Best practices for optimizing React components?',
        timestamp: new Date(Date.now() - 1000 * 60 * 60 * 48), // 2 days ago
        messages: []
      },
      {
        id: '5',
        title: 'Material UI Theme Customization',
        lastMessage: 'How to create custom Material UI themes?',
        timestamp: new Date(Date.now() - 1000 * 60 * 60 * 48 - 1000 * 60 * 60 * 3), // 2 days, 3 hours ago
        messages: []
      }
    ]
  }
];

// Quick action options
export const quickActions = [
  'Write Rule template',
  'Improve Rule template',
  'Analyze the rule'
];

// Mock AI responses for variety
export const mockAIResponses = [
  "That's an interesting question! Let me help you with that.",
  "I understand what you're looking for. Here's my response:",
  "Great idea! Here's how we can approach this:",
  "I'd be happy to help you with that request.",
  "That's a thoughtful question. Let me provide a detailed response.",
  "Excellent choice! Here's what I think about that:",
  "I can definitely help you with this. Here's my analysis:"
];

// Utility functions
export const generateId = () => {
  return Date.now().toString() + Math.random().toString(36).substr(2, 9);
};

export const formatTimestamp = (timestamp) => {
  const now = new Date();
  const diff = now - timestamp;
  const minutes = Math.floor(diff / (1000 * 60));
  const hours = Math.floor(diff / (1000 * 60 * 60));
  const days = Math.floor(diff / (1000 * 60 * 60 * 24));

  if (minutes < 1) return 'Just now';
  if (minutes < 60) return `${minutes}m ago`;
  if (hours < 24) return `${hours}h ago`;
  if (days < 7) return `${days}d ago`;
  
  return timestamp.toLocaleDateString();
};

export const createMessage = (text, sender = 'user') => {
  return {
    id: generateId(),
    text,
    sender,
    timestamp: new Date()
  };
};

export const getRandomAIResponse = (userMessage) => {
  const randomResponse = mockAIResponses[Math.floor(Math.random() * mockAIResponses.length)];
  return `${randomResponse}\n\nThis is a mock response to your message: "${userMessage}"`;
};

// Navigation items
export const navigationItems = [
//   {
//     id: 'discover',
//     title: 'Discover',
//     description: 'Your daily news and inspiration',
//     icon: '🧭',
//     color: '#fb923c'
//   },
//   {
//     id: 'labs',
//     title: 'Labs',
//     description: 'Experimental AI initiatives',
//     icon: '🧪',
//     color: '#f472b6'
//   }
];

// Local storage keys
export const STORAGE_KEYS = {
  CONVERSATIONS: 'copilot_conversations',
  CURRENT_CHAT: 'copilot_current_chat',
  USER_PREFERENCES: 'copilot_preferences'
};