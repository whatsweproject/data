import React from 'react';
import WelcomeScreen from './WelcomeScreen.js';
import MessageList from './MessageList.js';
import ChatInput from './ChatInput.js';

const ChatArea = ({ 
  messages = [], 
  isLoading = false, 
  showWelcome = true,
  onSendMessage,
  onFileUpload,
  onQuickAction,
  userName = 'WhatsWe'
}) => {
  
  const handleSendMessage = (messageData) => {
    if (onSendMessage) {
      onSendMessage(messageData);
    }
  };

  const handleFileUpload = (files) => {
    if (onFileUpload) {
      onFileUpload(files);
    }
  };

  const handleQuickAction = (action) => {
    if (onQuickAction) {
      onQuickAction(action);
    }
  };

  return (
    <div className="chat-area">
      <div className="chat-content">
        {showWelcome && messages.length === 0 ? (
          <WelcomeScreen 
            onQuickAction={handleQuickAction}
            userName={userName}
          />
        ) : (
          <MessageList 
            messages={messages}
            isLoading={isLoading}
          />
        )}
      </div>
      
      <div className="chat-input-section">
        <ChatInput
          onSendMessage={handleSendMessage}
          onFileUpload={handleFileUpload}
          disabled={isLoading}
          placeholder="Message Copilot"
        />
      </div>
    </div>
  );
};

export default ChatArea;

// Add component-specific styles
const styles = `
.chat-area {
  flex: 1;
  display: flex;
  flex-direction: column;
  height: 100vh;
  background-color: var(--background-color);
  overflow: hidden;
}

.chat-content {
  flex: 1;
  display: flex;
  flex-direction: column;
  padding: 24px 24px 0 24px;
  overflow: hidden;
  min-height: 0; /* Important for flex scrolling */
}

.chat-input-section {
  padding: 0 24px 24px 24px;
  flex-shrink: 0;
}

/* Responsive Design */
@media (max-width: 768px) {
  .chat-content {
    padding: 16px 16px 0 16px;
  }
  
  .chat-input-section {
    padding: 0 16px 16px 16px;
  }
}

@media (max-width: 640px) {
  .chat-content {
    padding: 12px 12px 0 12px;
  }
  
  .chat-input-section {
    padding: 0 12px 12px 12px;
  }
}

/* Focus management for accessibility */
.chat-area:focus-within .chat-input-section {
  /* Add subtle visual feedback when input is focused */
}

/* Print styles */
@media print {
  .chat-area {
    height: auto;
    overflow: visible;
  }
  
  .chat-input-section {
    display: none;
  }
  
  .chat-content {
    padding: 0;
    overflow: visible;
  }
}
`;

// Inject styles if not already present
if (!document.querySelector('#chat-area-styles')) {
  const styleSheet = document.createElement('style');
  styleSheet.id = 'chat-area-styles';
  styleSheet.textContent = styles;
  document.head.appendChild(styleSheet);
}