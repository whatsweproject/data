import React, { useState, useEffect } from 'react';
import Sidebar from './Sidebar.js';
import ChatArea from './ChatArea.js';
import { 
  mockConversationHistory, 
  createMessage, 
  getRandomAIResponse,
  generateId,
  STORAGE_KEYS 
} from '../utils/mockData.js';

// Import global styles
import '../styles/styles.css';

const App = () => {
  // State management
  const [conversations, setConversations] = useState(mockConversationHistory);
  const [currentChatId, setCurrentChatId] = useState(null);
  const [currentMessages, setCurrentMessages] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [activeNavItem, setActiveNavItem] = useState('discover');

  // Load saved data on component mount
  useEffect(() => {
    loadSavedData();
  }, []);

  // Save data when conversations or current chat changes
  useEffect(() => {
    saveData();
  }, [conversations, currentChatId, currentMessages]);

  const loadSavedData = () => {
    try {
      const savedConversations = localStorage.getItem(STORAGE_KEYS.CONVERSATIONS);
      const savedCurrentChat = localStorage.getItem(STORAGE_KEYS.CURRENT_CHAT);
      
      if (savedConversations) {
        setConversations(JSON.parse(savedConversations));
      }
      
      if (savedCurrentChat) {
        const chatData = JSON.parse(savedCurrentChat);
        setCurrentChatId(chatData.id);
        setCurrentMessages(chatData.messages || []);
      }
    } catch (error) {
      console.error('Error loading saved data:', error);
    }
  };

  const saveData = () => {
    try {
      localStorage.setItem(STORAGE_KEYS.CONVERSATIONS, JSON.stringify(conversations));
      
      if (currentChatId && currentMessages.length > 0) {
        localStorage.setItem(STORAGE_KEYS.CURRENT_CHAT, JSON.stringify({
          id: currentChatId,
          messages: currentMessages
        }));
      }
    } catch (error) {
      console.error('Error saving data:', error);
    }
  };

  const handleSendMessage = async (messageData) => {
    const { text, files } = messageData;
    
    if (!text.trim() && (!files || files.length === 0)) return;

    // If no current chat, create a new one
    if (!currentChatId) {
      startNewChat();
    }

    // Create user message
    const userMessage = createMessage(text, 'user');
    
    // Add file information to message if files are attached
    if (files && files.length > 0) {
      userMessage.files = files.map(file => ({
        name: file.name,
        size: file.size,
        type: file.type
      }));
    }

    // Update current messages
    setCurrentMessages(prev => [...prev, userMessage]);
    setIsLoading(true);

    // Simulate AI response delay
    try {
      await new Promise(resolve => setTimeout(resolve, 1000 + Math.random() * 2000));
      
      const aiResponse = createMessage(getRandomAIResponse(text), 'assistant');
      setCurrentMessages(prev => [...prev, aiResponse]);
    } catch (error) {
      console.error('Error getting AI response:', error);
      const errorMessage = createMessage('Sorry, I encountered an error. Please try again.', 'assistant');
      setCurrentMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleFileUpload = (files) => {
    console.log('Files uploaded:', files);
    // Here you would typically upload files to your backend
    // For now, we just log them
  };

  const handleQuickAction = (action) => {
    // When a quick action is clicked, it should populate the input
    // This is handled by the ChatInput component, but we can also
    // automatically send the message if desired
    handleSendMessage({ text: action, files: [] });
  };

  const handleConversationSelect = (conversation) => {
    setCurrentChatId(conversation.id);
    setCurrentMessages(conversation.messages || []);
  };

  const startNewChat = () => {
    const newChatId = generateId();
    setCurrentChatId(newChatId);
    setCurrentMessages([]);
    
    // Clear current chat from localStorage
    localStorage.removeItem(STORAGE_KEYS.CURRENT_CHAT);
  };

  const handleNavItemSelect = (itemId) => {
    setActiveNavItem(itemId);
    // You can add logic here to handle different nav item selections
    console.log('Nav item selected:', itemId);
  };

  const toggleSidebar = () => {
    setSidebarCollapsed(!sidebarCollapsed);
  };

  // Determine if we should show the welcome screen
  const showWelcome = !currentChatId || currentMessages.length === 0;

  return (
    <div className="app">
      {/* Mobile sidebar overlay */}
      {sidebarCollapsed && (
        <div 
          className="sidebar-overlay"
          onClick={() => setSidebarCollapsed(false)}
        />
      )}

      <Sidebar
        currentChatId={currentChatId}
        onConversationSelect={handleConversationSelect}
        onNewChat={startNewChat}
        onNavItemSelect={handleNavItemSelect}
        isCollapsed={sidebarCollapsed}
      />

      <div className="main-content">
        {/* Header with menu toggle for mobile */}
        <header className="app-header">
          <button 
            className="menu-toggle"
            onClick={toggleSidebar}
            aria-label="Toggle sidebar"
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
              <path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"/>
            </svg>
          </button>
          
          <div className="header-title">
            {currentChatId ? 'Chat' : 'Copilot'}
          </div>
          
          <div className="header-actions">
            {currentChatId && (
              <button 
                className="new-chat-header-btn"
                onClick={startNewChat}
                title="Start new chat"
              >
                <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/>
                </svg>
              </button>
            )}
          </div>
        </header>

        <ChatArea
          messages={currentMessages}
          isLoading={isLoading}
          showWelcome={showWelcome}
          onSendMessage={handleSendMessage}
          onFileUpload={handleFileUpload}
          onQuickAction={handleQuickAction}
          userName="WhatsWe"
        />
      </div>
    </div>
  );
};

export default App;

// Add app-specific styles
const styles = `
.app {
  display: flex;
  height: 100vh;
  background-color: var(--background-color);
  font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', sans-serif;
}

.main-content {
  flex: 1;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.app-header {
  display: none;
  align-items: center;
  justify-content: space-between;
  padding: 12px 16px;
  background: var(--surface-color);
  border-bottom: 1px solid var(--border-color);
  min-height: 56px;
}

.menu-toggle {
  width: 40px;
  height: 40px;
  border: none;
  background: none;
  color: var(--text-muted);
  cursor: pointer;
  border-radius: var(--radius-md);
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.2s;
}

.menu-toggle:hover {
  background-color: var(--hover-bg);
  color: var(--text-secondary);
}

.header-title {
  font-size: 18px;
  font-weight: 600;
  color: var(--text-primary);
}

.header-actions {
  display: flex;
  gap: 8px;
}

.new-chat-header-btn {
  width: 40px;
  height: 40px;
  border: none;
  background: var(--primary-color);
  color: white;
  cursor: pointer;
  border-radius: var(--radius-md);
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.2s;
}

.new-chat-header-btn:hover {
  background-color: #2563eb;
  transform: scale(1.05);
}

.sidebar-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  z-index: 999;
  display: none;
}

/* Mobile styles */
@media (max-width: 768px) {
  .app-header {
    display: flex;
  }
  
  .sidebar-overlay {
    display: block;
  }
}

@media (max-width: 640px) {
  .app {
    flex-direction: column;
  }
  
  .header-title {
    font-size: 16px;
  }
  
  .menu-toggle,
  .new-chat-header-btn {
    width: 36px;
    height: 36px;
  }
}

/* Focus states for accessibility */
.menu-toggle:focus,
.new-chat-header-btn:focus {
  outline: 2px solid var(--primary-color);
  outline-offset: 2px;
}

/* Loading state for the entire app */
.app.loading {
  cursor: wait;
}

/* Error boundary styles */
.error-boundary {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100vh;
  padding: 20px;
  text-align: center;
}

.error-boundary h2 {
  color: #ef4444;
  margin-bottom: 16px;
}

.error-boundary p {
  color: var(--text-muted);
  margin-bottom: 24px;
}

.error-boundary button {
  background: var(--primary-color);
  color: white;
  border: none;
  padding: 12px 24px;
  border-radius: var(--radius-md);
  cursor: pointer;
  font-size: 14px;
}

/* High contrast mode support */
@media (prefers-contrast: high) {
  .app {
    border: 2px solid var(--text-primary);
  }
}

/* Reduced motion support */
@media (prefers-reduced-motion: reduce) {
  .menu-toggle,
  .new-chat-header-btn {
    transition: none;
  }
  
  .new-chat-header-btn:hover {
    transform: none;
  }
}
`;

// Inject styles if not already present
if (!document.querySelector('#app-styles')) {
  const styleSheet = document.createElement('style');
  styleSheet.id = 'app-styles';
  styleSheet.textContent = styles;
  document.head.appendChild(styleSheet);
}