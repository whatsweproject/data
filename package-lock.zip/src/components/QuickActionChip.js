import React from 'react';

const QuickActionChip = ({ text, onClick, className = '' }) => {
  const handleClick = () => {
    if (onClick) {
      onClick(text);
    }
  };

  return (
    <button
      className={`quick-action-chip ${className}`}
      onClick={handleClick}
      type="button"
    >
      {text}
    </button>
  );
};

export default QuickActionChip;

// Add component-specific styles
const styles = `
.quick-action-chip {
  padding: 8px 16px;
  background: var(--surface-color);
  border: 1px solid var(--border-color);
  border-radius: var(--radius-xl);
  font-size: 14px;
  color: var(--text-secondary);
  cursor: pointer;
  transition: all 0.2s ease;
  font-family: inherit;
  white-space: nowrap;
  outline: none;
}

.quick-action-chip:hover {
  background-color: var(--hover-bg);
  border-color: #cbd5e1;
  transform: translateY(-1px);
}

.quick-action-chip:active {
  transform: translateY(0);
}

.quick-action-chip:focus {
  outline: 2px solid var(--primary-color);
  outline-offset: 2px;
}

@media (max-width: 640px) {
  .quick-action-chip {
    font-size: 12px;
    padding: 6px 12px;
  }
}
`;

// Inject styles if not already present
if (!document.querySelector('#quick-action-chip-styles')) {
  const styleSheet = document.createElement('style');
  styleSheet.id = 'quick-action-chip-styles';
  styleSheet.textContent = styles;
  document.head.appendChild(styleSheet);
}