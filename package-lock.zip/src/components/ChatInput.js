import React, { useState, useRef, useEffect } from 'react';

const ChatInput = ({ 
  onSendMessage, 
  onFileUpload, 
  disabled = false, 
  placeholder = "Message Copilot",
  maxLength = 4000 
}) => {
  const [message, setMessage] = useState('');
  const [attachedFiles, setAttachedFiles] = useState([]);
  const textareaRef = useRef(null);
  const fileInputRef = useRef(null);

  // Auto-resize textarea
  const adjustTextareaHeight = () => {
    const textarea = textareaRef.current;
    if (textarea) {
      textarea.style.height = 'auto';
      textarea.style.height = Math.min(textarea.scrollHeight, 800) + 'px';
    }
  };

  useEffect(() => {
    adjustTextareaHeight();
  }, [message]);

  const handleInputChange = (e) => {
    const value = e.target.value;
    if (value.length <= maxLength) {
      setMessage(value);
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleSendMessage = () => {
    const trimmedMessage = message.trim();
    if (!trimmedMessage && attachedFiles.length === 0) return;
    if (disabled) return;

    // Send message with attached files
    onSendMessage({
      text: trimmedMessage,
      files: attachedFiles
    });

    // Reset form
    setMessage('');
    setAttachedFiles([]);
    adjustTextareaHeight();
  };

  const handleFileSelect = (e) => {
    const files = Array.from(e.target.files);
    setAttachedFiles(prev => [...prev, ...files]);
    
    // Call parent handler if provided
    if (onFileUpload) {
      onFileUpload(files);
    }
    
    // Reset file input
    e.target.value = '';
  };

  const removeFile = (index) => {
    setAttachedFiles(prev => prev.filter((_, i) => i !== index));
  };

  const handleFileUploadClick = () => {
    fileInputRef.current?.click();
  };

  const handleVoiceInput = () => {
    // Placeholder for voice input functionality
    alert('Voice input feature would be implemented here');
  };

  const formatFileSize = (bytes) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  return (
    <div className="chat-input-container">
      {/* File attachments preview */}
      {attachedFiles.length > 0 && (
        <div className="attached-files">
          {attachedFiles.map((file, index) => (
            <div key={index} className="attached-file">
              <div className="file-info">
                <span className="file-name">{file.name}</span>
                <span className="file-size">{formatFileSize(file.size)}</span>
              </div>
              <button 
                className="remove-file-btn"
                onClick={() => removeFile(index)}
                type="button"
                aria-label={`Remove ${file.name}`}
              >
                ×
              </button>
            </div>
          ))}
        </div>
      )}

      <div className="chat-input-wrapper">
        <div className="chat-input-avatar">C</div>
        
        <div className="input-container">
          <textarea
            ref={textareaRef}
            className="chat-input"
            placeholder={placeholder}
            value={message}
            onChange={handleInputChange}
            onKeyDown={handleKeyDown}
            disabled={disabled}
            rows={1}
            maxLength={maxLength}
          />
          
          <div className="input-actions">
            <button
              className="input-action-btn"
              onClick={handleFileUploadClick}
              disabled={disabled}
              title="Attach file"
              type="button"
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                <path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/>
              </svg>
            </button>
            
            <button
              className="input-action-btn"
              onClick={handleVoiceInput}
              disabled={disabled}
              title="Voice input"
              type="button"
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 14c1.66 0 3-1.34 3-3V5c0-1.66-1.34-3-3-3S9 3.34 9 5v6c0 1.66 1.34 3 3 3z"/>
                <path d="M17 11c0 2.76-2.24 5-5 5s-5-2.24-5-5H5c0 3.53 2.61 6.43 6 6.92V21h2v-3.08c3.39-.49 6-3.39 6-6.92h-2z"/>
              </svg>
            </button>
          </div>
        </div>

        <div className="quick-response">
          <svg className="quick-response-icon" viewBox="0 0 24 24" fill="currentColor">
            <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
          </svg>
          <span>Quick response</span>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
            <path d="M7 10l5 5 5-5z"/>
          </svg>
        </div>
      </div>

      {/* Character count */}
      {message.length > maxLength * 0.8 && (
        <div className="character-count">
          {message.length}/{maxLength}
        </div>
      )}

      {/* Hidden file input */}
      <input
        ref={fileInputRef}
        type="file"
        className="hidden-file-input"
        multiple
        accept="*/*"
        onChange={handleFileSelect}
      />
    </div>
  );
};

export default ChatInput;

// Add component-specific styles
const styles = `
.chat-input-container {
  max-width: 900px;
  margin: 0 auto;
  width: 100%;
}

.attached-files {
  background: var(--surface-color);
  border-radius: var(--radius-lg) var(--radius-lg) 0 0;
  padding: 12px 16px;
  border: 1px solid var(--border-color);
  border-bottom: none;
  box-shadow: var(--shadow-sm);
}

.attached-file {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 8px 12px;
  background: var(--hover-bg);
  border-radius: var(--radius-md);
  margin-bottom: 8px;
}

.attached-file:last-child {
  margin-bottom: 0;
}

.file-info {
  display: flex;
  flex-direction: column;
  gap: 2px;
  flex: 1;
  min-width: 0;
}

.file-name {
  font-size: 14px;
  color: var(--text-primary);
  font-weight: 500;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.file-size {
  font-size: 12px;
  color: var(--text-light);
}

.remove-file-btn {
  width: 20px;
  height: 20px;
  border: none;
  background: var(--border-color);
  color: var(--text-muted);
  border-radius: 50%;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 14px;
  font-weight: bold;
  transition: all 0.2s;
  flex-shrink: 0;
}

.remove-file-btn:hover {
  background: #ef4444;
  color: white;
}

.chat-input-wrapper {
  background: var(--surface-color);
  border-radius: var(--radius-lg);
  padding: 16px;
  box-shadow: var(--shadow-md);
  display: flex;
  align-items: flex-end;
  gap: 12px;
  border: 1px solid var(--border-color);
}

.chat-input-wrapper.has-files {
  border-radius: 0 0 var(--radius-lg) var(--radius-lg);
}

.chat-input-avatar {
  width: 32px;
  height: 32px;
  background: var(--primary-gradient);
  border-radius: var(--radius-sm);
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  font-size: 12px;
  font-weight: bold;
  flex-shrink: 0;
}

.input-container {
  flex: 1;
  position: relative;
}

.chat-input {
  width: 100%;
  border: 1px solid var(--border-color);
  border-radius: var(--radius-md);
  padding: 12px 50px 12px 16px;
  font-size: 14px;
  font-family: inherit;
  resize: none;
  min-height: 100px;
  max-height: 200px;
  outline: none;
  transition: border-color 0.2s;
  background: var(--surface-color);
  color: var(--text-primary);
  line-height: 1.4;
}

.chat-input:focus {
  border-color: var(--primary-color);
}

.chat-input:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}

.chat-input::placeholder {
  color: var(--text-light);
}

.input-actions {
  position: absolute;
  right: 8px;
  top: 50%;
  transform: translateY(-50%);
  display: flex;
  gap: 4px;
}

.input-action-btn {
  width: 28px;
  height: 28px;
  border: none;
  background: none;
  border-radius: var(--radius-sm);
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--text-muted);
  transition: all 0.2s;
}

.input-action-btn:hover:not(:disabled) {
  background-color: var(--hover-bg);
  color: var(--text-secondary);
}

.input-action-btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.quick-response {
  display: flex;
  align-items: center;
  gap: 4px;
  font-size: 14px;
  color: var(--text-muted);
  flex-shrink: 0;
  cursor: pointer;
  padding: 4px 8px;
  border-radius: var(--radius-sm);
  transition: all 0.2s;
}

.quick-response:hover {
  background-color: var(--hover-bg);
}

.quick-response-icon {
  width: 16px;
  height: 16px;
}

.character-count {
  text-align: right;
  font-size: 12px;
  color: var(--text-light);
  margin-top: 4px;
  padding-right: 8px;
}

.character-count.warning {
  color: #f59e0b;
}

.character-count.error {
  color: #ef4444;
}

.hidden-file-input {
  display: none;
}

/* Responsive Design */
@media (max-width: 768px) {
  .chat-input-wrapper {
    padding: 12px;
    gap: 8px;
  }
  
  .chat-input-avatar {
    width: 28px;
    height: 28px;
    font-size: 11px;
  }
  
  .chat-input {
    padding: 10px 45px 10px 12px;
    font-size: 16px; /* Prevents zoom on iOS */
  }
  
  .quick-response span {
    display: none;
  }
}

@media (max-width: 640px) {
  .chat-input-wrapper {
    padding: 10px;
  }
  
  .attached-files {
    padding: 8px 12px;
  }
  
  .attached-file {
    padding: 6px 8px;
  }
}

/* Focus states for accessibility */
.input-action-btn:focus {
  outline: 2px solid var(--primary-color);
  outline-offset: 2px;
}

.quick-response:focus {
  outline: 2px solid var(--primary-color);
  outline-offset: 2px;
}
`;

// Inject styles if not already present
if (!document.querySelector('#chat-input-styles')) {
  const styleSheet = document.createElement('style');
  styleSheet.id = 'chat-input-styles';
  styleSheet.textContent = styles;
  document.head.appendChild(styleSheet);
}