import React from 'react';
import QuickActionChip from './QuickActionChip.js';
import { quickActions } from '../utils/mockData.js';

const WelcomeScreen = ({ onQuickAction, userName = 'WhatsWe' }) => {
  return (
    <div className="welcome-screen">
      <h3 className="welcome-title">
        Hey, Ask anything or choose something from below.
      </h3>
      
      <div className="quick-actions">
        {quickActions.map((action, index) => (
          <QuickActionChip
            key={index}
            text={action}
            onClick={onQuickAction}
          />
        ))}
      </div>

      {/* Optional: Add some inspiring prompts or recent topics */}
      <div className="welcome-suggestions">
        <p className="suggestions-text">
        </p>
      </div>
    </div>
  );
};

export default WelcomeScreen;

// Add component-specific styles
const styles = `
.welcome-screen {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  flex: 1;
  max-width: 800px;
  margin: 0 auto;
  text-align: center;
  padding: 40px 20px;
  animation: welcomeFadeIn 0.6s ease-out;
}

.welcome-title {
  font-size: 1rem;
  font-weight: 200;
  color: var(--text-primary);
  margin-bottom: 32px;
  line-height: 1.2;
}

.quick-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  margin-bottom: 32px;
  justify-content: center;
  max-width: 600px;
}

.welcome-suggestions {
  margin-top: 20px;
}

.suggestions-text {
  font-size: 14px;
  color: var(--text-light);
  font-style: italic;
}

@keyframes welcomeFadeIn {
  from {
    opacity: 0;
    transform: translateY(20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

/* Responsive Design */
@media (max-width: 768px) {
  .welcome-screen {
    padding: 20px 16px;
  }
  
  .welcome-title {
    font-size: 1.5rem;
    margin-bottom: 24px;
  }
  
  .quick-actions {
    margin-bottom: 24px;
    max-width: 100%;
  }
}

@media (max-width: 640px) {
  .welcome-title {
    font-size: 1.3rem;
    margin-bottom: 20px;
  }
  
  .quick-actions {
    gap: 6px;
    margin-bottom: 20px;
  }
}

/* Animation for quick actions appearing */
.quick-actions .quick-action-chip {
  animation: chipFadeIn 0.5s ease-out forwards;
  opacity: 0;
}

.quick-actions .quick-action-chip:nth-child(1) { animation-delay: 0.1s; }
.quick-actions .quick-action-chip:nth-child(2) { animation-delay: 0.2s; }
.quick-actions .quick-action-chip:nth-child(3) { animation-delay: 0.3s; }
.quick-actions .quick-action-chip:nth-child(4) { animation-delay: 0.4s; }
.quick-actions .quick-action-chip:nth-child(5) { animation-delay: 0.5s; }
.quick-actions .quick-action-chip:nth-child(6) { animation-delay: 0.6s; }
.quick-actions .quick-action-chip:nth-child(7) { animation-delay: 0.7s; }
.quick-actions .quick-action-chip:nth-child(8) { animation-delay: 0.8s; }

@keyframes chipFadeIn {
  from {
    opacity: 0;
    transform: translateY(10px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}
`;

// Inject styles if not already present
if (!document.querySelector('#welcome-screen-styles')) {
  const styleSheet = document.createElement('style');
  styleSheet.id = 'welcome-screen-styles';
  styleSheet.textContent = styles;
  document.head.appendChild(styleSheet);
}