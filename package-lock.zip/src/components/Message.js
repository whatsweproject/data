import React from 'react';
import { formatTimestamp } from '../utils/mockData.js';

const Message = ({ message, showTimestamp = false }) => {
  const { text, sender, timestamp } = message;
  const isUser = sender === 'user';

  // Format text with line breaks
  const formatText = (text) => {
    return text.split('\n').map((line, index) => (
      <React.Fragment key={index}>
        {line}
        {index < text.split('\n').length - 1 && <br />}
      </React.Fragment>
    ));
  };

  return (
    <div className="message">
      <div className={`message-avatar ${sender}`}>
        {isUser ? 'U' : 'A'}
      </div>
      <div className="message-content-wrapper">
        <div className="message-content">
          {formatText(text)}
        </div>
        {showTimestamp && (
          <div className="message-timestamp">
            {formatTimestamp(timestamp)}
          </div>
        )}
      </div>
    </div>
  );
};

export default Message;

// Add component-specific styles
const styles = `
.message {
  display: flex;
  gap: 12px;
  margin-bottom: 16px;
  animation: messageSlideIn 0.3s ease-out;
}

.message-avatar {
  width: 32px;
  height: 32px;
  border-radius: var(--radius-sm);
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  font-size: 12px;
  font-weight: 600;
  flex-shrink: 0;
}

.message-avatar.user {
  background-color: var(--primary-color);
}

.message-avatar.assistant {
  background-color: var(--text-muted);
}

.message-content-wrapper {
  flex: 1;
  max-width: calc(100% - 44px);
}

.message-content {
  background: var(--surface-color);
  padding: 16px;
  border-radius: var(--radius-lg);
  box-shadow: var(--shadow-sm);
  line-height: 1.6;
  color: var(--text-primary);
  word-wrap: break-word;
  overflow-wrap: break-word;
}

.message-content code {
  background-color: #f1f5f9;
  padding: 2px 6px;
  border-radius: 4px;
  font-family: 'Monaco', 'Menlo', 'Ubuntu Mono', monospace;
  font-size: 13px;
}

.message-content pre {
  background-color: #f8fafc;
  padding: 12px;
  border-radius: 6px;
  overflow-x: auto;
  margin: 8px 0;
  border-left: 3px solid var(--primary-color);
}

.message-content pre code {
  background: none;
  padding: 0;
}

.message-timestamp {
  font-size: 11px;
  color: var(--text-light);
  margin-top: 4px;
  padding-left: 4px;
}

@keyframes messageSlideIn {
  from {
    opacity: 0;
    transform: translateY(10px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

/* Loading message animation */
.message.loading .message-content {
  position: relative;
  color: var(--text-light);
}

.message.loading .message-content::after {
  content: '●●●';
  animation: loadingDots 1.5s infinite;
  margin-left: 4px;
}

@keyframes loadingDots {
  0%, 20% { opacity: 0; }
  50% { opacity: 1; }
  100% { opacity: 0; }
}

@media (max-width: 640px) {
  .message {
    gap: 8px;
    margin-bottom: 12px;
  }
  
  .message-avatar {
    width: 28px;
    height: 28px;
    font-size: 11px;
  }
  
  .message-content {
    padding: 12px;
    font-size: 14px;
  }
  
  .message-content-wrapper {
    max-width: calc(100% - 36px);
  }
}
`;

// Inject styles if not already present
if (!document.querySelector('#message-styles')) {
  const styleSheet = document.createElement('style');
  styleSheet.id = 'message-styles';
  styleSheet.textContent = styles;
  document.head.appendChild(styleSheet);
}