import React, { useState } from 'react';
import { navigationItems, mockConversationHistory } from '../utils/mockData.js';

const Sidebar = ({ 
  currentChatId, 
  onConversationSelect, 
  onNewChat, 
  onNavItemSelect,
  isCollapsed = false 
}) => {
  const [activeNavItem, setActiveNavItem] = useState('discover');

  const handleNavItemClick = (itemId) => {
    setActiveNavItem(itemId);
    if (onNavItemSelect) {
      onNavItemSelect(itemId);
    }
  };

  const handleConversationClick = (conversation) => {
    if (onConversationSelect) {
      onConversationSelect(conversation);
    }
  };

  const handleNewChatClick = () => {
    if (onNewChat) {
      onNewChat();
    }
  };

  const BrandHeader = () => (
    <div className="brand-header">
      <div className="brand-logo">C</div>
      {!isCollapsed && <div className="brand-name">Copilot</div>}
    </div>
  );

  const NavigationSection = () => (
    <div className="nav-sections">
      {navigationItems.map((item) => (
        <div
          key={item.id}
          className={`nav-item ${activeNavItem === item.id ? 'active' : ''}`}
          onClick={() => handleNavItemClick(item.id)}
        >
          <div 
            className="nav-icon"
            style={{ backgroundColor: item.color }}
          >
            {item.icon}
          </div>
          {!isCollapsed && (
            <div className="nav-content">
              <h3>{item.title}</h3>
              <p>{item.description}</p>
            </div>
          )}
        </div>
      ))}
    </div>
  );

  const ConversationHistory = () => (
    <div className="conversations-section">
      <div className="conversations-header">
        <span>Conversations</span>
        <button 
          className="new-chat-btn"
          onClick={handleNewChatClick}
          title="Start new chat"
        >
          <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
            <path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/>
          </svg>
        </button>
      </div>
      
      {mockConversationHistory.map((section, sectionIndex) => (
        <div key={sectionIndex} className="conversation-group">
          <div className="conversation-date">{section.section}</div>
          {section.conversations.map((conversation) => (
            <div
              key={conversation.id}
              className={`conversation-item ${currentChatId === conversation.id ? 'active' : ''}`}
              onClick={() => handleConversationClick(conversation)}
            >
              <div className="conversation-title">{conversation.title}</div>
              {!isCollapsed && (
                <div className="conversation-preview">
                  {conversation.lastMessage}
                </div>
              )}
            </div>
          ))}
        </div>
      ))}
    </div>
  );

  return (
    <div className={`sidebar ${isCollapsed ? 'collapsed' : ''}`}>
      <BrandHeader />
      <div className="divider" />
      {!isCollapsed && <ConversationHistory />}
    </div>
  );
};

export default Sidebar;

// Add component-specific styles
const styles = `
.sidebar {
  width: 280px;
  background: var(--surface-color);
  border-right: 1px solid var(--border-color);
  display: flex;
  flex-direction: column;
  height: 100vh;
  transition: width 0.3s ease;
}

.sidebar.collapsed {
  width: 60px;
}

.brand-header {
  padding: 16px;
  display: flex;
  align-items: center;
  gap: 8px;
  border-bottom: 1px solid var(--border-light);
  min-height: 64px;
}

.brand-logo {
  width: 28px;
  height: 28px;
  background: var(--primary-gradient);
  border-radius: var(--radius-sm);
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  font-size: 14px;
  font-weight: bold;
  flex-shrink: 0;
}

.brand-name {
  font-size: 18px;
  font-weight: 600;
  color: var(--text-primary);
  transition: opacity 0.3s ease;
}

.nav-sections {
  padding: 16px;
}

.nav-item {
  display: flex;
  align-items: center;
  padding: 12px;
  border-radius: var(--radius-md);
  cursor: pointer;
  margin-bottom: 8px;
  transition: background-color 0.2s;
}

.nav-item:hover {
  background-color: var(--hover-bg);
}

.nav-item.active {
  background-color: var(--active-bg);
}

.nav-icon {
  width: 20px;
  height: 20px;
  margin-right: 12px;
  border-radius: var(--radius-sm);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 12px;
  color: white;
  flex-shrink: 0;
}

.sidebar.collapsed .nav-icon {
  margin-right: 0;
}

.nav-content {
  transition: opacity 0.3s ease;
}

.nav-content h3 {
  font-size: 14px;
  font-weight: 600;
  color: var(--text-primary);
  margin-bottom: 2px;
}

.nav-content p {
  font-size: 12px;
  color: var(--text-muted);
  line-height: 1.3;
}

.divider {
  height: 1px;
  background-color: var(--border-color);
  margin: 0 16px;
}

.conversations-section {
  padding: 16px;
  flex: 1;
  overflow-y: auto;
  overflow-x: hidden;
}

.conversations-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-size: 14px;
  font-weight: 600;
  color: var(--text-muted);
  margin-bottom: 12px;
}

.new-chat-btn {
  width: 24px;
  height: 24px;
  border: none;
  background: none;
  color: var(--text-light);
  cursor: pointer;
  border-radius: var(--radius-sm);
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.2s;
}

.new-chat-btn:hover {
  background-color: var(--hover-bg);
  color: var(--text-muted);
}

.conversation-group {
  margin-bottom: 20px;
}

.conversation-date {
  font-size: 12px;
  color: var(--text-light);
  margin-bottom: 8px;
  font-weight: 500;
}

.conversation-item {
  padding: 8px 12px;
  border-radius: var(--radius-sm);
  cursor: pointer;
  transition: all 0.2s;
  margin-bottom: 4px;
  border-left: 3px solid transparent;
}

.conversation-item:hover {
  background-color: var(--hover-bg);
}

.conversation-item.active {
  background-color: #e0f2fe;
  border-left-color: var(--primary-color);
}

.conversation-title {
  font-size: 14px;
  color: var(--text-secondary);
  font-weight: 500;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  margin-bottom: 2px;
}

.conversation-preview {
  font-size: 12px;
  color: var(--text-light);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  line-height: 1.3;
}

/* Scrollbar styling for conversations */
.conversations-section::-webkit-scrollbar {
  width: 4px;
}

.conversations-section::-webkit-scrollbar-track {
  background: transparent;
}

.conversations-section::-webkit-scrollbar-thumb {
  background: var(--border-color);
  border-radius: 2px;
}

.conversations-section::-webkit-scrollbar-thumb:hover {
  background: var(--text-light);
}

/* Responsive Design */
@media (max-width: 768px) {
  .sidebar {
    width: 240px;
  }
  
  .brand-header {
    padding: 12px;
  }
  
  .nav-sections {
    padding: 12px;
  }
  
  .conversations-section {
    padding: 12px;
  }
}

@media (max-width: 640px) {
  .sidebar {
    position: fixed;
    left: 0;
    top: 0;
    z-index: 1000;
    transform: translateX(-100%);
    transition: transform 0.3s ease;
  }
  
  .sidebar.open {
    transform: translateX(0);
  }
  
  .conversation-preview {
    display: none;
  }
}

/* Focus states for accessibility */
.nav-item:focus,
.conversation-item:focus,
.new-chat-btn:focus {
  outline: 2px solid var(--primary-color);
  outline-offset: 2px;
}

/* Animation for conversation items */
.conversation-item {
  animation: conversationItemSlide 0.2s ease-out;
}

@keyframes conversationItemSlide {
  from {
    opacity: 0;
    transform: translateX(-10px);
  }
  to {
    opacity: 1;
    transform: translateX(0);
  }
}

/* Collapsed state adjustments */
.sidebar.collapsed .nav-content,
.sidebar.collapsed .brand-name {
  display: none;
}

.sidebar.collapsed .nav-item {
  justify-content: center;
  padding: 12px 8px;
}

.sidebar.collapsed .brand-header {
  justify-content: center;
}
`;

// Inject styles if not already present
if (!document.querySelector('#sidebar-styles')) {
  const styleSheet = document.createElement('style');
  styleSheet.id = 'sidebar-styles';
  styleSheet.textContent = styles;
  document.head.appendChild(styleSheet);
}