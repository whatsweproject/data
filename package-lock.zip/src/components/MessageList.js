import React, { useEffect, useRef } from 'react';
import Message from './Message.js';

const MessageList = ({ messages, isLoading = false }) => {
  const messagesEndRef = useRef(null);
  const messagesContainerRef = useRef(null);

  // Auto-scroll to bottom when new messages arrive
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Loading message component
  const LoadingMessage = () => (
    <div className="message loading">
      <div className="message-avatar assistant">A</div>
      <div className="message-content-wrapper">
        <div className="message-content">
          Thinking...
        </div>
      </div>
    </div>
  );

  if (messages.length === 0 && !isLoading) {
    return null; // Don't render anything if no messages
  }

  return (
    <div 
      ref={messagesContainerRef}
      className="message-list custom-scrollbar"
    >
      <div className="messages-container">
        {messages.map((message) => (
          <Message 
            key={message.id} 
            message={message} 
            showTimestamp={false} // You can make this configurable
          />
        ))}
        
        {isLoading && <LoadingMessage />}
        
        {/* Invisible element to scroll to */}
        <div ref={messagesEndRef} />
      </div>
    </div>
  );
};

export default MessageList;

// Add component-specific styles
const styles = `
.message-list {
  flex: 1;
  overflow-y: auto;
  overflow-x: hidden;
  padding: 0 4px; /* Small padding for scrollbar */
  margin-bottom: 20px;
  min-height: 0; /* Important for flex scrolling */
}

.messages-container {
  padding: 16px 0;
  max-width: 800px;
  margin: 0 auto;
  width: 100%;
}

/* Smooth scrolling behavior */
.message-list {
  scroll-behavior: smooth;
}

/* Fade in animation for the entire message list */
.message-list {
  animation: messageListFadeIn 0.3s ease-out;
}

@keyframes messageListFadeIn {
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
}

/* Empty state styles (when no messages) */
.message-list:empty {
  display: none;
}

/* Focus styles for accessibility */
.message-list:focus {
  outline: 2px solid var(--primary-color);
  outline-offset: -2px;
}

/* Loading indicator positioning */
.message.loading {
  opacity: 0.7;
}

/* Responsive adjustments */
@media (max-width: 768px) {
  .messages-container {
    padding: 12px 0;
  }
  
  .message-list {
    margin-bottom: 16px;
  }
}

@media (max-width: 640px) {
  .messages-container {
    padding: 8px 0;
  }
  
  .message-list {
    padding: 0 2px;
    margin-bottom: 12px;
  }
}

/* High contrast mode support */
@media (prefers-contrast: high) {
  .message-list {
    border: 1px solid var(--text-primary);
  }
}

/* Reduced motion for accessibility */
@media (prefers-reduced-motion: reduce) {
  .message-list {
    scroll-behavior: auto;
  }
  
  .message-list,
  .messages-container {
    animation: none;
  }
}

/* Print styles */
@media print {
  .message-list {
    overflow: visible;
    height: auto;
    page-break-inside: avoid;
  }
}
`;

// Inject styles if not already present
if (!document.querySelector('#message-list-styles')) {
  const styleSheet = document.createElement('style');
  styleSheet.id = 'message-list-styles';
  styleSheet.textContent = styles;
  document.head.appendChild(styleSheet);
}